<?php get_header(); ?>

<?php if(!ISMOBILE) : ?> 
    
<?php endif ?> 