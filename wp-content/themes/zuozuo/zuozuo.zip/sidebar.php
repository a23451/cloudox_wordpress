<?php echo "<h1>sidebar</h1>";

wp_list_categories();

 ?>