<!-- footer -->
        <div style="background: url(images/bottom.jpg) center 0;position: relative;"><!--background-color:#00825f;-->
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 col-md-6" style="text-align: right;margin-top: 45px;margin-bottom: 40px;">
                        <h4 style="font-size: 26px; color: white;margin-bottom: 20px;">注册即可免费试用15天</h4>
                        <p style="font-size: 18px;color: white;">优秀的客户体验从现在开始</p>
                    </div> 
                    <div class="col-xs-6 col-md-6">
                        <a href="javascript:;" class="btn btn-default" style="margin-top: 80px;margin-left: 12px;border-color: white;height: 42px;width: 150px;border-radius: 80px;background: none;color: white;font-size: 18px;border-width: 2px;">免费注册</a>
                    </div>
                </div>
            </div>
        </div>        
        

        <div style="background: url(images/tinet_cloud_dark.jpg) center 0;background-repeat: no-repeat;" class="visible-lg-block visible-md-block">
            <div class="container" style="height: 100%;padding-left: 0px;padding-right: 0px;">
                <div class="row" style="margin-top: 50px;color: #FFFFFF;">
                    <div class="col-lg-3 col-xs-3 col-md-3">
                        <h5 style="line-height: 24px;">联系我们</h5>
                        <label style="color: #929292;font-size: 13px;line-height: 21px;margin-bottom: 15px;font-weight: lighter;">销售咨询</label><span style="margin-left: 10px;">021-96999725</span><br>
                        <label style="color: #929292;font-size: 13px;line-height: 21px;margin-bottom: 15px;font-weight: lighter;">售后服务</label><span style="margin-left: 10px;">400&nbsp;821&nbsp;7363</span><br>
                        <label style="color: #929292;font-size: 13px;line-height: 21px;margin-bottom: 15px;font-weight: lighter;">官方微信</label><span style="margin-left: 10px;"><br>
                        <img src="images/weixin.jpg" style="border: solid 0px #4d4e4c;margin-bottom: 40px;width:90px;height:90px;"><br>
                        <a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;"><label style="color: #929292;font-size: 13px;line-height: 21px;margin-bottom: 15px;font-weight: lighter;">北京 | 上海 | 深圳 | 广州</label></a>
                    </span></div>
                    <div class="col-lg-7 col-xs-3 col-md-7">
                        <div class="row">
                            <div class="col-lg-3 col-md-3">
                                <h5 style="line-height: 24px;">产品</h5>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">CTI-Cloud</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">全能行</a></p>
                            </div>
                            <div class="col-lg-3 col-xs-3 col-md-3">
                                <h5 style="line-height: 24px;">解决方案</h5>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">保险</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">在线教育</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">新金融</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">本地生活</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">电子商务</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">旅游</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">汽车服务</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">房产装修</a></p>
                            </div>
                            <div class="col-lg-3 col-xs-3 col-md-3">
                            <a href="javascript:;" style="color: #FFFFFF"><h5 style="margin-bottom: 40px; ">客户案例</h5></a>
                                <h5 style="line-height: 24px;">关于我们</h5>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">企业介绍</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">联系我们</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">加入我们</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">友情链接</a></p>
                            </div>
                            <div class="col-lg-3 col-xs-3 col-md-3">
                                <h5 style="line-height: 24px;">快速入口</h5>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;">博客</a></p>
                                <p style="margin-bottom: 0px;"><a href="javascript:;" style="color: #929292;font-size: 14px;line-height: 28px;" target="_blank">接口文档</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-xs-2 col-md-2" style="text-align: center;padding-left: 0px;padding-right: 0px;">
                        <!--<div class="row">
                            <div>
                                <h5 style="line-height: 24px;">中国电信</h5>
                                <a href="http://www.chinatelecom.com.cn/" rel="nofollow" style="color: #929292;font-size: 14px;line-height: 28px;">
                                    <img src="images/dianxin.png" style="border: solid 1px #4d4e4c;">
                                </a>
                            </div>
                        </div>-->

                        <div class="row">
                            <div>
                                <a href="https://www.aliyun.com/" rel="nofollow" style="color: #929292;font-size: 14px;line-height: 28px;">
                                    <h5 style="line-height: 24px;">阿里云</h5>
                                </a>
                                <a href="https://www.aliyun.com/" rel="nofollow" style="color: #929292;font-size: 14px;line-height: 28px;">
                                    <img src="images/aliyun.png" style="width:130px;height:34px;">
                                </a>
                            </div>
                        </div>
                
                    </div>  
                </div>
            </div>  
        </div>


        <div style="background-color: #292828;">
            <div class="container">
                <div style="padding-top: 15px;padding-bottom: 1px;text-align: center;color: #5a5a5a;font-size: 12px;">
                    <p>COPYRIGHT © 2016-2017 CLOUDOX. ALL RIGHTS RESERVED. 版权所有 保歌（上海）金融信息服务有限公司   呼叫中心运营许可证：B2-20161138 京ICP备xxxxxxxx号</p>
                </div>
            </div>
        </div>

       
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="js/ie10-viewport-bug-workaround.js"></script>
    </body>
</html>
       